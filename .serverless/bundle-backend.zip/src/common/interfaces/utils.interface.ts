export interface Pagination {
    data: any;
    total: number;
    page: number;
    lastPage: number;
}
