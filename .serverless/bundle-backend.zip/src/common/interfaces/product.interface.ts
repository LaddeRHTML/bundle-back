export interface KeyValueObject {
    key: string;
    value: string;
}
