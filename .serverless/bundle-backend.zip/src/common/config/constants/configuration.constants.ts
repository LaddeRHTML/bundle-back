export const ErrorMessages = {
    connection_string_message: 'No connection string has been provided in the .env file.',
    jwt_exp_message: 'No token expiration string has been provided in the .env file.',
    collection_name_message: 'No Collection name string has been provided in the .env file.'
};
