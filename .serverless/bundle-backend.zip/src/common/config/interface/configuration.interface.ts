export interface CollectionNames {
    ordersCollectionName: string;
    clientsCollectionName: string;
}
