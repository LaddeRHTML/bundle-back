export const apiVersion = 'api/v1';
