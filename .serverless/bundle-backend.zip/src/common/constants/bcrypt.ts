export const hashRounds = 1;
