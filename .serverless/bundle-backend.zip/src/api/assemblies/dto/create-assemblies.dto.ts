import { Assembly } from '../schema/assemblies.schema';

export class CreateAssemblyDto extends Assembly {}
