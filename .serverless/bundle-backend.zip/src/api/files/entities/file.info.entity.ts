export class FileInfo {
    length: number;
    chunkSize: number;
    filename: string;
    md5: string;
    contentType: string;
}
