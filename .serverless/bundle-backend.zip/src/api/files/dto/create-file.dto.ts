export class CreateFileDto {
    readonly name: string;
    readonly encoding: string;
    readonly type: string;
}
