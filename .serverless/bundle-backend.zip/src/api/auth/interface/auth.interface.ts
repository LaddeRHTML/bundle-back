export interface AccessToken {
    access_token: string;
}
