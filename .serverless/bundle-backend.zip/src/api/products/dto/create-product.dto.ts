import { Product } from '../schema/products.schema';

export class CreateProductDto extends Product {}
