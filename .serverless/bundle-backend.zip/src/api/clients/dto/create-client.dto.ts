import { Client } from '../schema/clients.schema';

export class CreateClientDto extends Client {}
