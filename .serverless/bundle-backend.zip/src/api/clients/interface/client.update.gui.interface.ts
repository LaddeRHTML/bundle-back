import { QueryOptions } from "mongoose";

export interface UpdateSettings extends QueryOptions {}