import { Accessory } from '../schema/accessories.schema';

export class CreateAccessoryDto extends Accessory {}
