import { User, UserSettings } from '../schema/user.schema';

export class CreateUserDto extends User {}

export class CreateUserSettingsDto extends UserSettings {}
