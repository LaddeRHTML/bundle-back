export interface UserPasswords {
    oldPassword: string;
    newPassword: string;
}
