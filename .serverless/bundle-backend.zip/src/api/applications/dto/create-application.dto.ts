import { Application } from '../schema/applications.schema';

export class CreateApplicationDto extends Application {}
