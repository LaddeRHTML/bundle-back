export type DeliveredBy = 'Kirill' | 'Stepan' | 'Roman' | 'Oleg' | 'Azamat' | 'Curier';
