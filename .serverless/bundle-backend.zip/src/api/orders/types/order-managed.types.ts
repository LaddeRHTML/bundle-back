export type OrderManaged = 'Kirill' | 'Stepan' | 'Roman' | 'Oleg' | 'Azamat';
