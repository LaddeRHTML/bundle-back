export type OrderStatus = 'first-touch' | 'client-ready' | 'purchased' | 'closed';
