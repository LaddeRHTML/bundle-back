import { Order } from '../schema/orders.schema';

export class CreateOrderDto extends Order {}
